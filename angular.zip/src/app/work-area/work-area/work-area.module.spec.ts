import { WorkAreaModule } from './work-area.module';

describe('WorkAreaModule', () => {
  let workAreaModule: WorkAreaModule;

  beforeEach(() => {
    workAreaModule = new WorkAreaModule();
  });

  it('should create an instance', () => {
    expect(workAreaModule).toBeTruthy();
  });
});
