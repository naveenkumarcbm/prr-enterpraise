import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkAreaComponent } from './work-area.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [WorkAreaComponent]
})
export class WorkAreaModule { }
