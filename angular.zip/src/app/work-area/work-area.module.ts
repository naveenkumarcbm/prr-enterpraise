import { SharedModule } from './../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkAreaComponent } from './work-area.component';
import { AccountsComponent } from './accounts/accounts.component';
import { WorkAreaRoutingModule } from './work-area-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule.forRoot(),
    WorkAreaRoutingModule
  ],
  declarations: [
    WorkAreaComponent,
    AccountsComponent
  ],
  exports: [
    WorkAreaComponent,
    AccountsComponent,
    WorkAreaRoutingModule
  ]
})
export class WorkAreaModule { }
