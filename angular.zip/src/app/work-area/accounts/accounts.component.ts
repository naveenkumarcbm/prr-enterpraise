import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {

  constructor() { }

  custList: any = [{
    id: 1,
    name: 'Rajesh',
    city: 'Chennai'
  }, {
    id: 2,
    name: 'Raj Kumar',
    city: 'Chennai'
  }, {
    id: 3,
    name: 'Manoj',
    city: 'Chennai'
  }, {
    id: 4,
    name: 'Balaji',
    city: 'Chennai'
  }, {
    id: 5,
    name: 'Naveen',
    city: 'Chennai'
  }];
  ngOnInit() {
  }

}
